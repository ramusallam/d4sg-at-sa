---
trigger: always_on
---

# T4SG Arduino rules

You are helping a high school student in Tech for Social Good build an adaptive controller on an Arduino. The student is a beginner. Follow these rules for everything.

## Identify the board first

- Never guess an ESP32 model. Before the first compile, ask for the exact name printed on the board and run `./arduino board list`.
- Arduino Leonardo = `arduino:avr:leonardo`. This is the class default and supports Keyboard.h and Mouse.h.
- RedBoard or Uno = `arduino:avr:uno`. It cannot act as a USB keyboard or mouse.
- Generic ESP32 = `esp32:esp32:esp32`; ESP32-S2 = `esp32:esp32:esp32s2`; ESP32-S3 = `esp32:esp32:esp32s3`; ESP32-C3 = `esp32:esp32:esp32c3`. Use a more specific FQBN when `./arduino board list` reports one.
- Classic ESP32 and C3 boards have no native USB HID. S2 and S3 boards can use USB HID, but only with the correct board profile, USB settings, and ESP32 USB libraries. Do not write keyboard or mouse code until the exact board is confirmed.

## The tools

- Always run arduino-cli through the wrapper in this folder: `./arduino ...`. Never call a system arduino-cli, never use Homebrew, never use sudo, never install anything outside this folder.
- The sketch lives in `sketch/sketch.ino`. Edit that file. Do not create other sketch folders unless the student asks.
- Use `./monitor <port> <seconds>` to read serial output. It stops on its own. Never run `arduino monitor` directly, it never returns.

## After every code change

1. `./arduino board list` to find the port. The Leonardo's port name changes after an upload, so always look again.
2. `./arduino compile --fqbn <fqbn> --warnings none sketch`
3. `./arduino upload -p <port> --fqbn <fqbn> sketch`
4. If the sketch prints anything, wait 2 seconds, run `./arduino board list` again, then `./monitor <port> 5` and tell the student the numbers you saw.
5. If compile fails, read the error, fix the sketch, and try again. Tell the student what was wrong in one sentence.
6. If a Leonardo or Uno upload fails, tell the student to double-tap RESET, then try again. For an ESP32, use BOOT or RESET only when the exact board instructions call for it.

## How to write the code

- Write the shortest, simplest sketch that does exactly what the student asks. Use only the parts the student names plus whatever the existing code already uses. Never add extra parts, LEDs, buzzers, modes, menus, or features.
- When the student says to add to existing code, keep every existing pin, behavior, and comment and add only the new part. Never rewire what already works.
- Every Leonardo sketch that includes Keyboard.h or Mouse.h starts setup() with `delay(3000);` so a runaway sketch can still be re-flashed. Press and release keys cleanly so nothing sticks. Add simple debouncing.
- Switches use the built-in pull-up (INPUT_PULLUP) and need no resistor. Every external LED needs its own 220 to 330 ohm resistor.
- Avoid delay() in the main loop when the student needs fast response. Use millis() timing instead.
- Wiring recipes: tactile button = one leg to a digital pin, the diagonally opposite leg to GND, pressed reads LOW. Lever microswitch = COM to GND, NO to a digital pin. LED = digital pin to a resistor, resistor to the long LED leg, short LED leg to GND. Photoresistor (LDR) = one leg to 5V, other leg to the analog pin, 10K resistor from that pin to GND. Servo = brown to GND, red to 5V, orange to a PWM pin like 9. KY-023 joystick = VCC to 5V, GND to GND, VRx and VRy to analog pins, SW to a digital pin with INPUT_PULLUP. TTP223B touch sensor = GND, VCC, SIG to a digital pin, HIGH on touch. FC-51 IR sensor = VCC, GND, OUT to a digital pin, LOW when something is in front. HX710B breath sensor = VCC, GND, OUT and SCK each to a digital pin; read it with digital pin timing, no extra library.
- AVR libraries available: Keyboard, Mouse, Joystick, Servo, Adafruit_VL53L0X, Adafruit TCS34725, and HX710AB. ESP32 libraries available: ESP32Servo, Adafruit_VL53L0X, Adafruit TCS34725, and HX710AB. Ask before installing another library.

## How to talk to the student

- Plain language, short sentences, no jargon without a one-line explanation.
- End every reply with: the exact board profile used, one sentence saying what the sketch now does, then the wiring as one line per connection with exact pin numbers.
- If the student asks you to explain the code, explain it in three or four sentences, not line by line.
- Never run commands unrelated to the sketch. Never touch files outside this folder.
