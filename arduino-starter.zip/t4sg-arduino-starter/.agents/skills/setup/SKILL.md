---
name: setup
description: One-time setup for this folder. Installs arduino-cli into ./bin and the class cores and libraries into the folder. Run once per laptop.
---

# /setup

1. From the folder root run `./setup.sh`. Show the student the last few lines. It installs arduino-cli into `./bin`, the Arduino AVR core (Leonardo and Uno), and the libraries Keyboard, Mouse, Servo, Joystick, Adafruit_VL53L0X, Adafruit TCS34725, and HX710AB. It ends by compiling the starter sketch.
2. If it prints `SETUP COMPLETE`, tell the student: "Setup is done. Plug in your board and type /check."
3. If the download fails with a TLS or certificate error, the school network is blocking it. Tell the student to switch to a phone hotspot and run `/setup` again. Do not try to work around the network any other way.
4. If `setup.sh` is not executable, run `chmod +x arduino setup.sh monitor` once and try again.
