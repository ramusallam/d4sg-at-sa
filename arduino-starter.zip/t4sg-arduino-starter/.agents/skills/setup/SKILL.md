---
name: setup
description: One-time setup for Leonardo or RedBoard/Uno. Installs arduino-cli, the AVR core, and class libraries inside this folder.
---

# /setup

1. Confirm the board is a Leonardo, RedBoard, or Uno. If it is an ESP32, stop and use `/setup-esp32` instead.
2. From the folder root run `./setup.sh avr`. Show the student the last few lines. It installs arduino-cli into `./bin`, the Arduino AVR core, and the class libraries. It ends by compiling the starter sketch.
3. If it prints `SETUP COMPLETE`, tell the student: "Setup is done. Plug in your board and type /check."
4. If the download fails with a TLS or certificate error, stop and tell the student to ask Ramsey. Do not change networks or bypass the block without his instruction.
5. If `setup.sh` is not executable, run `chmod +x arduino setup.sh monitor` once and try again.
