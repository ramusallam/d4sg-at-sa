---
name: upload
description: Compile the sketch, upload it to the board, and show five seconds of serial output.
---

# /upload

1. `./arduino board list` to find the port and board. Leonardo = `arduino:avr:leonardo`. RedBoard or Uno = `arduino:avr:uno`.
2. `./arduino compile --fqbn <fqbn> --warnings none sketch`. If it fails, fix the sketch and try again, then tell the student what was wrong in one sentence.
3. `./arduino upload -p <port> --fqbn <fqbn> sketch`. If it fails, tell the student to double-tap RESET and try again.
4. Wait 2 seconds, `./arduino board list` again, then `./monitor <port> 5`. Report the numbers or text you saw in plain words.
