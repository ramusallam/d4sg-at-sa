---
name: upload
description: Compile the sketch, upload it to the board, and show five seconds of serial output.
---

# /upload

1. Ask for the exact board name, then run `./arduino board list` to find the port and FQBN. Leonardo = `arduino:avr:leonardo`; RedBoard/Uno = `arduino:avr:uno`; ESP32 = `esp32:esp32:esp32`; S2 = `esp32:esp32:esp32s2`; S3 = `esp32:esp32:esp32s3`; C3 = `esp32:esp32:esp32c3`. Never guess between ESP32 families.
2. `./arduino compile --fqbn <fqbn> --warnings none sketch`. If it fails, fix the sketch and try again, then tell the student what was wrong in one sentence.
3. `./arduino upload -p <port> --fqbn <fqbn> sketch`. If a Leonardo or Uno upload fails, tell the student to double-tap RESET and try again. For ESP32, use BOOT or RESET only when the exact model instructions call for it.
4. Wait 2 seconds, `./arduino board list` again, then `./monitor <port> 5`. Report the FQBN, port, and numbers or text you saw in plain words.
