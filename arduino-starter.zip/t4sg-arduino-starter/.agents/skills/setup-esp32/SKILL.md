---
name: setup-esp32
description: One-time setup for an ESP32 board. Installs arduino-cli, the stable Espressif core, and class sensor libraries inside this folder.
---

# /setup-esp32

1. Ask the student for the exact model printed on the board. Explain that ESP32, ESP32-S2, ESP32-S3, and ESP32-C3 do not use the same board profile.
2. From the folder root run `./setup.sh esp32`. Review the command before running it. This installs the stable Espressif core from its official package index and compiles the starter sketch for a generic ESP32.
3. Run `./arduino board list`. If it reports a recognized FQBN, use it. Otherwise map the exact family: ESP32 = `esp32:esp32:esp32`, S2 = `esp32:esp32:esp32s2`, S3 = `esp32:esp32:esp32s3`, C3 = `esp32:esp32:esp32c3`.
4. If the student needs keyboard or mouse behavior, stop unless the board is an S2 or S3 with native USB and the exact USB settings are known. Classic ESP32 and C3 cannot act as USB keyboards.
5. If it prints `SETUP COMPLETE`, tell the student: "ESP32 tools are ready. Keep the board plugged in and type /check."
6. If the download is blocked, stop and tell the student to ask Ramsey. Do not change networks or bypass the block without his instruction.
