---
name: check
description: Proves the laptop can talk to the board. Finds the port, uploads the starter blink sketch, and shows serial output.
---

# /check

1. Run `./arduino board list`. Pick the port that shows an Arduino Leonardo, or, for a RedBoard, the `usbserial` or `wchusbserial` port. If no board shows, tell the student to check the cable and plug it in again, then stop.
2. Compile: `./arduino compile --fqbn arduino:avr:leonardo --warnings none sketch` (use `arduino:avr:uno` for a RedBoard).
3. Upload: `./arduino upload -p <port> --fqbn <fqbn> sketch`.
4. Wait 2 seconds, run `./arduino board list` again (the Leonardo's port can change), then `./monitor <port> 4`.
5. If you see "hello from the board", tell the student: "Your laptop and your board are talking. Say what you want to build." Also tell them which port the board is on.
6. If upload fails, tell the student to double-tap RESET on the board and run `/check` again.
