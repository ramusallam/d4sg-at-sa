---
name: check
description: Proves the laptop can talk to the board. Finds the port, uploads the portable serial test, and shows its output.
---

# /check

1. Ask for the exact board name, then run `./arduino board list`. If no board shows, tell the student to check that the cable carries data, plug it in again, and stop.
2. Choose the FQBN from the board list and the printed label. Leonardo = `arduino:avr:leonardo`; RedBoard/Uno = `arduino:avr:uno`; generic ESP32 = `esp32:esp32:esp32`; ESP32-S2 = `esp32:esp32:esp32s2`; ESP32-S3 = `esp32:esp32:esp32s3`; ESP32-C3 = `esp32:esp32:esp32c3`. Never guess between ESP32 families.
3. Compile: `./arduino compile --fqbn <fqbn> --warnings none sketch`.
4. Upload: `./arduino upload -p <port> --fqbn <fqbn> sketch`.
5. Wait 2 seconds, run `./arduino board list` again because the port can change, then `./monitor <port> 4`.
6. If you see "hello from the board", tell the student: "Your laptop and your board are talking. Say what you want to build." Report the exact FQBN and port.
7. If a Leonardo or Uno upload fails, tell the student to double-tap RESET and run `/check` again. For ESP32, use BOOT or RESET only when the exact model instructions call for it.
