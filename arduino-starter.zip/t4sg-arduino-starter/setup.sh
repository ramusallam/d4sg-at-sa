#!/bin/sh
# One-time setup. Installs arduino-cli into ./bin and the selected board core
# and libraries into this folder. Nothing is installed elsewhere on the laptop.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
MODE="${1:-avr}"
case "$MODE" in
  avr|esp32) ;;
  *) echo "Use: ./setup.sh [avr|esp32]"; exit 2 ;;
esac
mkdir -p bin build/cache
if [ ! -x bin/arduino-cli ]; then
  echo "Installing arduino-cli into ./bin"
  curl -fsSL https://raw.githubusercontent.com/arduino/arduino-cli/master/install.sh | BINDIR="$DIR/bin" sh
fi
./arduino version
./arduino core update-index
./arduino lib install "Adafruit_VL53L0X" "Adafruit BusIO" "Adafruit TCS34725" HX710AB
if [ "$MODE" = "esp32" ]; then
  echo "Installing the stable Espressif ESP32 board core"
  ./arduino core install esp32:esp32
  ./arduino lib install ESP32Servo
  CHECK_FQBN="esp32:esp32:esp32"
  BOARD_LABEL="ESP32. Tell the agent the exact model printed on your board before /check"
else
  ./arduino core install arduino:avr
  ./arduino lib install Keyboard Mouse Servo
  ./arduino lib install --git-url https://github.com/MHeironimus/ArduinoJoystickLibrary.git || echo "Joystick library skipped (needs network access to GitHub)"
  CHECK_FQBN="arduino:avr:leonardo"
  BOARD_LABEL="Leonardo or RedBoard/Uno"
fi
echo "Checking the compiler with the starter sketch"
./arduino compile --fqbn "$CHECK_FQBN" --warnings none sketch
echo
echo "SETUP COMPLETE for $BOARD_LABEL. Plug in your board and type /check."
