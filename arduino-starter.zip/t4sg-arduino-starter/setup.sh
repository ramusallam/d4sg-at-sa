#!/bin/sh
# One-time setup. Installs arduino-cli into ./bin and the class cores and
# libraries into this folder. Nothing is installed anywhere else on the laptop.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
mkdir -p bin
if [ ! -x bin/arduino-cli ]; then
  echo "Installing arduino-cli into ./bin"
  curl -fsSL https://raw.githubusercontent.com/arduino/arduino-cli/master/install.sh | BINDIR="$DIR/bin" sh
fi
./arduino version
./arduino core update-index
./arduino core install arduino:avr
./arduino lib install Keyboard Mouse Servo "Adafruit_VL53L0X" "Adafruit BusIO" "Adafruit TCS34725" HX710AB
./arduino lib install --git-url https://github.com/MHeironimus/ArduinoJoystickLibrary.git || echo "Joystick library skipped (needs network access to GitHub)"
echo "Checking the compiler with the starter sketch"
./arduino compile --fqbn arduino:avr:leonardo --warnings none sketch
echo
echo "SETUP COMPLETE. Plug in your board and type /check."
