// Portable starter sketch. Says hello over Serial on Arduino and ESP32 boards.
// Replace this with what you are building.
void setup() {
  Serial.begin(115200);
  delay(500);
}

void loop() {
  Serial.println("hello from the board");
  delay(1000);
}
