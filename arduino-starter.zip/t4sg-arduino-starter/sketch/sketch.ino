// Starter sketch. Blinks the board's built-in LED and says hello over Serial.
// Replace this with what you are building.
void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.begin(115200);
}

void loop() {
  digitalWrite(LED_BUILTIN, HIGH);
  Serial.println("hello from the board");
  delay(500);
  digitalWrite(LED_BUILTIN, LOW);
  delay(500);
}
