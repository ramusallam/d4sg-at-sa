# T4SG Arduino starter

This folder lets you build on your Arduino with the Antigravity agent. Everything installs inside this folder. Nothing else on your laptop changes.

## Setup, once

1. Install Antigravity IDE from antigravity.google/download. Pick "Antigravity IDE", not "Antigravity 2.0". Sign in with your school Google account.
2. Unzip this folder onto your Desktop. Rename it with your name, for example `arduino-maya`.
3. In Antigravity: File, Open Folder, pick your folder.
4. In the agent chat, type `/setup` and press Enter. When it asks to run a command, click Run. This takes a few minutes the first time.
5. Plug in your board. Type `/check`. If the board blinks and the agent reports "hello from the board", you are set.

## Every build day

1. Plug in your board. Open your folder in Antigravity.
2. Say what you want in plain words. "A button on pin 4 presses the space bar." Paste code if you already have some.
3. The agent writes the sketch, compiles it, uploads it, and watches the serial output for five seconds. It tells you what it saw.
4. Test it on the real thing. Say what is wrong, in plain words. Repeat until it works.
5. Before you move on, ask "explain this loop to me in three sentences" and check it against your wiring. That is your notebook entry.

## When it breaks

- Board not found: unplug it, plug it back in, say "try again".
- Upload hangs: double-tap the RESET button on the board, then say "upload again".
- The board is typing everywhere: hold RESET, then upload. Every keyboard sketch starts with a three-second pause for exactly this reason.
- Anything else: ask "what went wrong?" and read the answer before clicking Run again.

## Turning it in

Copy the finished code into the Arduino Code Loading Tool on the T4SG hub and click Save to benchmark. Draw the wiring in the Wiring Schematic Tool. Drop your video.

## What is in here

- `sketch/sketch.ino` is your code. The agent edits this.
- `./arduino`, `./setup.sh`, `./monitor` are helpers the agent runs. You do not need to touch them.
- `.agents/` holds the rules and skills the agent follows. You do not need to open it.
