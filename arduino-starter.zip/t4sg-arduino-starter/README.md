# T4SG Arduino starter

This folder lets you vibe code any T4SG project or benchmark on your Arduino with the Antigravity agent. Everything installs inside this folder. Nothing else on your laptop changes.

## What this is

The browser tool on the T4SG hub is a copy machine: you ask Gemini for code, paste it in, click Upload, and carry any error back to Gemini yourself.

Antigravity is an agent. It is an AI that can run programs on your laptop, not just write text. It has the compiler, the upload tool, and the serial monitor, and your board is plugged into it. So it does the whole loop on its own: write, compile, upload, watch the board, adjust, upload again. You stay in plain English the whole time. That is agentic coding: you say what should happen, the agent works the tools until it does, and it shows you its work.

Why it is better: the agent sees the real error and the real serial numbers, a change-upload-test loop takes about fifteen seconds, and any board or library works. When the browser tool is still better: nothing to install, and you read every line because you have to. The browser tool is always where you turn work in.

## Setup, once

1. Install Antigravity IDE from antigravity.google/download. Two downloads are offered. Pick "Antigravity IDE", not Antigravity 2.0. Drag it to Applications, open it, sign in with your school Google account.
2. Unzip this folder onto your Desktop. Rename it with your name, for example `arduino-maya`.
3. In Antigravity: File, Open Folder, pick your folder. If it asks whether you trust the folder, click Yes.
4. The agent chat is the panel on the right. Type `/setup` and press Enter. Each time a gray box asks to run a command, click Run. The first time takes a few minutes and ends with SETUP COMPLETE.
5. Plug in your board. Type `/check`. If the board blinks and the agent reports "hello from the board", you are set.

## Every build day

1. Plug in your board. Open Antigravity. Your folder is under File, Open Recent.
2. Say what you want, one thing at a time. Name the parts and pins if you know them. "A button on pin 4 presses the space bar." Paste code if you already have some and say "start from this."
3. Click Run when it asks. The agent writes the sketch, compiles it, uploads it, and watches the serial output for five seconds. Every reply ends with what the sketch does now and the wiring, one line per connection.
4. Wire it from that list. Test it on the real thing.
5. Describe what happened, not "fix it." "The LED stays on." "It jumps too late." The agent can only fix what it knows about.
6. Repeat until it works.
7. Before you move on, ask "explain this loop to me in three sentences" and check it against your wiring. That is your notebook entry. If you cannot explain it, you are not done.

## When it breaks

- Board not found: unplug it, plug it back in, say "try again".
- Upload hangs: double-tap the RESET button on the board, then say "upload again".
- The board is typing everywhere: hold RESET, then upload. Every keyboard sketch starts with a three-second pause for exactly this reason.
- Setup fails on a certificate or TLS error: the school network blocked the download. Switch to a phone hotspot and type `/setup` again.
- Anything else: ask "what went wrong?" and read the answer before clicking Run again.

## Turning it in

Copy the finished code into the Arduino Code Loading Tool on the T4SG hub and click Save to benchmark. Draw the wiring in the Wiring Schematic Tool. Drop your video.

## What is in here

- `sketch/sketch.ino` is your code. The agent edits this.
- `./arduino`, `./setup.sh`, `./monitor` are helpers the agent runs. You do not need to touch them.
- `.agents/` holds the rules and skills the agent follows. You do not need to open it.
