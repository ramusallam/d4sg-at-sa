# T4SG Arduino starter

This folder lets you build a T4SG Arduino or ESP32 project with the Antigravity IDE agent. The compiler, board cores, and libraries install inside this folder. Nothing else on your laptop changes.

## Choose the right lane

Use the T4SG browser loading tool for the quickest first upload to a Leonardo or RedBoard/Uno. Use this Antigravity workspace when your build needs repeated edits, serial tuning, extra libraries, or an ESP32 toolchain.

The board still matters:

- Arduino Leonardo is the class default. It can act as a USB keyboard or mouse.
- RedBoard and Uno can run sensors, lights, and motors, but cannot act as a USB keyboard or mouse.
- ESP32 is a family. The exact model must be identified before compiling. Classic ESP32 and C3 boards cannot act as USB keyboards. S2 and S3 boards can, with the correct USB settings and libraries.

## Setup, once

1. Install Antigravity IDE from https://antigravity.google/download. During first-run setup, choose Review-driven development so you approve commands before they run.
2. Unzip this folder onto your Desktop. Rename it with your name, for example `arduino-maya`.
3. In Antigravity, choose File, then Open Folder, and pick your folder. Trust only the folder you just downloaded from the T4SG site.
4. In the agent panel on the right, type `/setup` for a Leonardo or RedBoard/Uno. Type `/setup-esp32` for an ESP32. Review each command before you click Run. The ESP32 core is a large first-time download and can take several minutes.
5. Plug in the board, type `/check`, and give the exact model printed on the board. When the agent reports "hello from the board", the toolchain is ready.

## Know the window

- Files on the left: `sketch/sketch.ino` is your working code.
- Editor in the center: inspect the code and each proposed change.
- Agent on the right: describe one behavior at a time and use `/setup`, `/setup-esp32`, `/check`, or `/upload`.
- Terminal at the bottom: read the compile, upload, and serial evidence.

## Every build day

1. Plug in your board and open this folder from File, then Open Recent.
2. Give the agent four things: the exact board, parts and pins, exact behavior, and what must stay unchanged.
3. Before you click Run, predict which code should change and what the board should do. Review the file and command.
4. Let the agent compile, upload, and read five seconds of serial output.
5. Wire from its exact connection list and test the physical result.
6. Report what you observed, not just "fix it." Useful evidence sounds like "the LED stays on," "it types w forever," or "nothing prints."
7. Before moving on, ask the agent to explain the loop in three sentences. Check the explanation against the code and wiring. If they do not match, ask one more question before moving on.

Example prompt:

`Leonardo. Button on pin 4. While held, hold the space bar; release it when the button is released. Keep my LED and its pin unchanged. Compile, upload, and show me the serial result.`

## When it breaks

- Board not found: confirm the USB cable carries data, unplug it, plug it back in, and run `/check` again.
- Compile fails: ask for the first error in one sentence, then repair only that error.
- Leonardo or Uno upload fails: double-tap RESET, then run `/upload` again.
- ESP32 upload fails: confirm the exact model. Use BOOT or RESET only when that board's instructions call for it.
- The Leonardo types everywhere: hold RESET, then ask the agent to upload the repaired sketch. Keyboard sketches start with a three-second safety pause.
- A setup download is blocked: stop and ask Ramsey. Do not change networks or bypass the block unless he asks.

## Turning it in

Copy the finished code into the Arduino Code Loading Tool on the T4SG hub and click Save to benchmark. For ESP32 code, use Save to benchmark but do not press Upload in the browser tool. Draw the wiring in the Wiring Schematic Tool, then add the required photo or video.

## What is in here

- `sketch/sketch.ino` is the code the agent edits.
- `./arduino`, `./setup.sh`, and `./monitor` are local helpers the agent runs.
- `.agents/rules/` contains the class hardware and safety rules.
- `.agents/skills/` contains the setup, board check, and upload workflows.
